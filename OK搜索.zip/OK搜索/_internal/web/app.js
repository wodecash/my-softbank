/* Lumen · 流光搜索 —— 前端逻辑
   与内核只通过 window.pywebview.api 通信（本地进程内调用，无 HTTP、无端口）。 */
'use strict';

const $ = (s) => document.querySelector(s);
const api = () => window.pywebview.api;

const state = {
  ready: false,
  boot: null,
  mode: 'name',
  drives: new Set(),
  showIdle: false,
  buckets: new Set(),
  results: [],
  sel: -1,
  query: '',
  token: 0,
  contentJob: null,
  previewFor: null,
  settings: {},
  searchToken: '',
  total: 0,
  keep: 0,
  loading: false,
  pageSize: 80,
  maxed: false,
  sort: 'relevance',      // 手动视图模式：relevance / name / type / size / mtime / opens
  sortAsc: false,
};

/* 手动视图模式：列名、默认方向、菜单脚注 */
const SORT_LABEL = {
  relevance: '相关度', name: '名称', type: '类型',
  size: '大小', mtime: '修改时间', opens: '打开次数',
};
const SORT_DEFAULT_ASC = {
  relevance: false, name: true, type: true, size: false, mtime: false, opens: false,
};
const SORT_NOTE = {
  relevance: '命中质量 + 打开频率 + 工作区加权',
  name: '文件名 A→Z；再点一次变 Z→A',
  type: '按文件类型分组，同组按名称',
  size: '大→小；再点一次变 小→大',
  mtime: '新→旧；再点一次变 旧→新',
  opens: '本机打开次数 多→少；再点一次反向',
};

const BUCKETS = {};   // id -> {name, color}
const IS_WIN = navigator.platform.toLowerCase().includes('win');
const MAX_TOKENS = 8;

/* ------------------------------------------------------------------ 工具 */
const esc = (s) => String(s).replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/* 空格（含全角空格/制表符）分隔的多关键词，小写、去重、限量。
   与后端 config.parse_query 保持一致。 */
function tokens(q) {
  if (!q) return [];
  const out = [];
  String(q).replace(/\u3000/g, ' ').split(/\s+/).forEach((raw) => {
    const t = raw.trim().toLowerCase().slice(0, 64);
    if (t && !out.includes(t) && out.length < MAX_TOKENS) out.push(t);
  });
  return out;
}

/* 高亮所有关键词；关键词按字面量匹配（escapeRe 处理特殊字符），不会抛异常。 */
function hl(text, q) {
  const safe = esc(text);
  const toks = tokens(q);
  if (!toks.length) return safe;
  const pattern = toks.map((t) => escapeRe(esc(t))).sort((a, b) => b.length - a.length).join('|');
  if (!pattern) return safe;
  try {
    return safe.replace(new RegExp(pattern, 'gi'), (m) => `<mark>${m}</mark>`);
  } catch (e) {
    return safe;
  }
}

function hex2rgb(h) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function mix(hex, target, amt) {
  const [r, g, b] = hex2rgb(hex);
  const t = target === 'w' ? 255 : 0;
  const f = (x) => Math.round(x + (t - x) * amt);
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}

function fmtCount(n) {
  if (!n) return '—';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e4) return (n / 1e3).toFixed(0) + 'k';
  return String(n);
}

let toastTimer = null;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

/* ---------------------------------------------------------------- 类型图标
   按扩展名细分：Word 蓝 W、Excel 绿 X、PPT 橙 P、PDF 红 PDF……
   目的就是像资源管理器那样，扫一眼就知道这是什么文件。
   文件夹 / 图片 / 视频 / 音频 / 压缩包 / 程序 这些本身形状就好认，保留图形。 */
const EXT_BADGE = {
  // Word 系
  doc: ['W', '#2B579A'], docx: ['W', '#2B579A'], docm: ['W', '#2B579A'],
  rtf: ['W', '#2B579A'], odt: ['W', '#2B579A'], wps: ['W', '#2B579A'],
  // Excel 系
  xls: ['X', '#1F7A45'], xlsx: ['X', '#1F7A45'], xlsm: ['X', '#1F7A45'],
  csv: ['X', '#1F7A45'], et: ['X', '#1F7A45'], numbers: ['X', '#1F7A45'],
  // PowerPoint 系
  ppt: ['P', '#C43E1C'], pptx: ['P', '#C43E1C'], dps: ['P', '#C43E1C'], key: ['P', '#C43E1C'],
  // 常见文档
  pdf: ['PDF', '#D93025'], txt: ['TXT', '#5A6472'], md: ['MD', '#55606E'],
  log: ['LOG', '#5A6472'], ofd: ['OFD', '#C43E1C'],
  // 图纸
  dwg: ['DWG', '#0E7490'], dxf: ['DXF', '#0891B2'], dwf: ['DWF', '#0891B2'],
  // 字体 / 数据库
  ttf: ['A', '#6E6BF5'], otf: ['A', '#6E6BF5'], woff: ['A', '#6E6BF5'], woff2: ['A', '#6E6BF5'],
  db: ['DB', '#0E7C86'], sqlite: ['DB', '#0E7C86'], mdb: ['DB', '#0E7C86'], accdb: ['DB', '#0E7C86'],
};
const MAIL_EXT = ['eml', 'msg', 'mbox', 'pst'];
const LINK_EXT = ['lnk', 'url', 'webloc'];
const ICON_FONT = "-apple-system,'Segoe UI Variable','Segoe UI',system-ui,sans-serif";

/* 统一底板：纯色圆角方块 + 共用高光（和原有的渐变图标保持同一种质感） */
function icoBox(inner, color) {
  return `<svg class="ico-svg" viewBox="0 0 32 32">
    <rect x="1" y="1" width="30" height="30" rx="8.5" fill="${color}"/>
    <rect x="1" y="1" width="30" height="30" rx="8.5" fill="url(#g-gloss)"/>
    <rect x="1" y="1" width="30" height="30" rx="8.5" fill="none"
      stroke="rgba(255,255,255,.22)" stroke-width=".8"/>${inner}</svg>`;
}

/* 字标：1 个字 15.5、2 个字 11、3 个字 8.2，保证都塞得下且不糊 */
function icoText(label, color) {
  const n = label.length;
  const size = n === 1 ? 15.5 : n === 2 ? 11 : 8.2;
  return icoBox(`<text x="16" y="16" text-anchor="middle" dominant-baseline="central"
    font-family="${ICON_FONT}" font-size="${size}" font-weight="700"
    fill="#fff" letter-spacing="${n > 2 ? '-.35' : '-.2'}">${label}</text>`, color);
}

function icoMail(color) {
  return icoBox(`<rect x="7.4" y="10.3" width="17.2" height="11.6" rx="2.1" fill="#fff"/>
    <path d="M8.3 12.1 16 17.4l7.7-5.3" fill="none" stroke="${color}"
      stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" opacity=".8"/>`, color);
}

function icoLink(color) {
  return icoBox(`<path d="M11.4 20.9 20.6 11.7" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/>
    <path d="M14.4 10.7h6.9v6.9" fill="none" stroke="#fff" stroke-width="2.6"
      stroke-linecap="round" stroke-linejoin="round"/>`, color);
}

function icon(bucket, ext) {
  const e = String(ext || '').toLowerCase();
  if (MAIL_EXT.includes(e)) return icoMail('#2F7BFF');
  if (LINK_EXT.includes(e)) return icoLink('#5C7CFA');
  const badge = EXT_BADGE[e];
  if (badge) return icoText(badge[0], badge[1]);
  const b = BUCKETS[bucket] ? bucket : 'other';
  return `<svg class="ico-svg" viewBox="0 0 32 32"><use href="#ic-${b}"/></svg>`;
}

/* ------------------------------------------------------------------ 初始化 */
async function init() {
  const boot = await api().boot();
  state.boot = boot;
  state.settings = boot.settings;
  applyTheme(boot.settings.theme);      // 先定主题，避免首帧闪一下深色
  boot.buckets.forEach((b) => { BUCKETS[b.id] = b; });

  $('#grads').innerHTML = boot.buckets.map((b) => `
    <linearGradient id="g-${b.id}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${mix(b.color, 'w', 0.26)}"/>
      <stop offset="0.55" stop-color="${b.color}"/>
      <stop offset="1" stop-color="${mix(b.color, 'b', 0.12)}"/>
    </linearGradient>`).join('');

  const activeDrives = new Set(boot.active_drives);
  boot.drives.forEach((d) => { if (activeDrives.has(d)) state.drives.add(d); });
  if (!state.drives.size && boot.drives.length) state.drives.add(boot.drives[0]);
  (boot.settings.buckets || []).forEach((b) => state.buckets.add(b));

  renderDrives();
  renderBuckets();
  renderIndexState();
  fitLayout();

  if (IS_WIN) {
    document.querySelectorAll('kbd').forEach((k) => {
      if (k.textContent.includes('⌘')) k.textContent = 'Ctrl+' + k.textContent.replace('⌘', '');
    });
    $('#hint').textContent = 'Ctrl K';
  }

  state.ready = true;
  $('#q').focus();
  bindEvents();
  positionPill();
  updateStatus();
  startWinWatch();
  state.sort = SORT_LABEL[boot.settings.sort] ? boot.settings.sort : 'relevance';
  state.sortAsc = !!boot.settings.sort_asc;
  syncSortUI();
}

function renderDrives() {
  const stat = state.boot.tiers.drives || {};
  const all = state.boot.drives || [];
  const cnt = (d) => (stat[d] || {}).count || 0;
  // 空盘（映射盘、刚插上还没建索引的移动硬盘）默认收起，不占侧栏位置；
  // 但全盘都没索引时（首次使用）仍然全列，否则没法勾选去建索引。
  const anyIdx = all.some((d) => cnt(d) > 0);
  const show = (state.showIdle || !anyIdx) ? all
    : all.filter((d) => cnt(d) > 0 || state.drives.has(d));
  const rows = show.map((d) => {
    const info = stat[d] || { count: 0 };
    const on = state.drives.has(d) ? 'on' : 'off';
    return `<div class="tier ${on}" data-drive="${d}">
      <div class="box"><svg viewBox="0 0 10 10" fill="none" stroke="#fff" stroke-width="1.7"
        stroke-linecap="round" stroke-linejoin="round"><path d="M2 5.3 4.1 7.3 8 2.8"/></svg></div>
      <svg class="drive-ico" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.25">
        <rect x="1.2" y="3.2" width="13.6" height="9.6" rx="2.4"/>
        <circle cx="11.6" cy="8" r=".9" fill="currentColor" stroke="none"/></svg>
      <span class="nm">${esc(d)} ${d === 'C:' ? '系统盘' : '数据盘'}</span>
      <span class="ct">${info.count ? fmtCount(info.count) : '未索引'}</span>
    </div>`;
  });
  const hidden = all.length - show.length;
  if (anyIdx && (hidden > 0 || state.showIdle)) {
    rows.push(`<div class="tier more" data-idle="1"><span class="nm">${
      state.showIdle ? '收起未建索引的盘符' : `＋ ${hidden} 个未建索引的盘符`}</span></div>`);
  }
  $('#drives').innerHTML = rows.join('');
}

function renderBuckets() {
  const st = state.boot.tiers.buckets || {};
  let total = 0;
  $('#buckets').innerHTML = state.boot.buckets.map((b) => {
    const c = (st[b.id] || {}).count || 0;
    total += c;
    const on = state.buckets.has(b.id) ? 'on' : 'off';
    return `<div class="tier ${on}" data-bucket="${b.id}">
      <div class="box"><svg viewBox="0 0 10 10" fill="none" stroke="#fff" stroke-width="1.7"
        stroke-linecap="round" stroke-linejoin="round"><path d="M2 5.3 4.1 7.3 8 2.8"/></svg></div>
      <span class="swatch" style="background:${b.color}"></span>
      <span class="nm">${esc(b.name)}</span>
      <span class="ct">${fmtCount(c)}</span>
    </div>`;
  }).join('');
  $('#bucket-sum').textContent = total ? fmtCount(total) + ' 项' : '未建立';
}

function renderIndexState() {
  const st = state.boot.tiers.drives || {};
  const total = Object.values(st).reduce((a, d) => a + (d.count || 0), 0);
  const builtAt = Math.max(0, ...Object.values(st).map((d) => d.built_at || 0));
  $('#idx-state').textContent = total ? `${fmtCount(total)} 条` : '空';
  $('#st-index').textContent = total
    ? `索引 ${total.toLocaleString()} 项 · 更新于 ${builtAt ? new Date(builtAt * 1000).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—'}`
    : '索引为空 · 点左下角「建立索引」开始';
}

/* ------------------------------------------------------------------ 搜索 */
let debounce = null;

function currentScope() {
  return {
    drives: [...state.drives],
    buckets: state.buckets.size ? [...state.buckets] : Object.keys(BUCKETS),
  };
}

function scheduleSearch() {
  clearTimeout(debounce);
  const raw = $('#q').value;
  state.query = raw;
  if (!tokens(raw).length) { clearResults(); return; }
  debounce = setTimeout(() => runSearch(raw), state.mode === 'content' ? 380 : 100);
}

/* 文件名搜索走后台任务：全量扫描 + 打分，界面先拿第一页，滚动到底再按需取下一页。
   任务机制保证再大的索引也不会把界面卡住，同时不被条数上限截断。 */
async function runSearch(q) {
  const my = ++state.token;
  state.loading = false;
  if (state.mode === 'name') {
    const scope = currentScope();
    $('#res-time').textContent = '检索中…';
    $('#st-mode').textContent = '文件名模式 · 全量扫描';
    const { job } = await api().search_start(q, scope.drives, scope.buckets,
      state.sort, state.sortAsc);
    if (my !== state.token) return;
    if (!job) { clearResults(); return; }
    pollSearch(job, my);
  } else {
    await runContent(q, my);
  }
}

async function pollSearch(job, my) {
  const p = await api().job_poll(job);
  if (my !== state.token) return;
  if (p.state === 'running') {
    setTimeout(() => pollSearch(job, my), 60);
    return;
  }
  if (p.state === 'error') { toast('搜索失败：' + p.error); return; }
  const res = p.result || {};
  state.searchToken = res.token || '';
  state.total = res.total || 0;
  state.keep = res.loaded || 0;
  state.pageSize = res.page_size || 80;
  state.results = res.hits || [];
  renderResults(res);
  $('#res-time').textContent = `${res.took_ms} ms`;
  $('#st-mode').textContent = `文件名模式 · 扫描 ${(res.scanned || 0).toLocaleString()} 条索引`;
}

async function loadMore() {
  if (state.mode !== 'name' || !state.searchToken || state.loading) return;
  const cap = state.keep || state.total;
  if (state.results.length >= Math.min(state.total, cap)) return;
  state.loading = true;
  const my = state.token;
  let r = null;
  try {
    r = await api().search_page(state.searchToken, state.results.length, state.pageSize);
  } finally {
    state.loading = false;
  }
  if (my !== state.token || !r || r.stale) return;
  const hits = r.hits || [];
  if (!hits.length) { state.total = state.results.length; updateCount(); return; }
  const base = state.results.length;
  state.results.push(...hits);
  appendRows(hits, base);
  updateCount();
}

function clearResults() {
  state.results = [];
  state.sel = -1;
  state.searchToken = '';
  state.total = 0;
  state.keep = 0;
  state.loading = false;
  $('#list').innerHTML = '';
  $('#empty').style.display = 'flex';
  $('#res-count').textContent = '0';
  $('#res-time').textContent = '';
  $('#res-label').textContent = '个结果';
  showPreviewEmpty();
}

function updateCount() {
  const total = state.total || 0;
  const shown = state.results.length;
  $('#res-count').textContent = total.toLocaleString();
  if (state.mode === 'content') return;
  let label = '个结果';
  if (shown < total) {
    label = `个结果 · 已显示 ${shown.toLocaleString()}`;
    if (state.keep && total > state.keep) {
      label += `（按${SORT_LABEL[state.sort] || '相关度'}保留前 ${state.keep.toLocaleString()} 条）`;
    }
  }
  $('#res-label').textContent = label;
}

function renderResults(res) {
  const q = state.query;
  const list = $('#list');
  if (!state.results.length) {
    list.innerHTML = '';
    $('#empty').style.display = 'flex';
    $('#empty').querySelector('h3').textContent = state.mode === 'content' ? '没有匹配的内容' : '没有找到文件';
    $('#empty').querySelector('p').innerHTML = state.mode === 'content'
      ? '内容搜索只扫描已建索引且属于文本类型的文件<br>可尝试缩短关键词或扩大索引范围'
      : '只按文件名匹配，父文件夹名不算命中<br>多个关键词需同时出现在文件名里，可检查左下角的索引范围与类型分层';
  } else {
    $('#empty').style.display = 'none';
    list.innerHTML = state.results.map((h, i) => rowHtml(h, i, q)).join('');
  }
  if (state.mode === 'content') {
    $('#res-count').textContent = state.results.length.toLocaleString();
    $('#res-label').textContent = `个文件 · 扫描 ${(res.scanned || 0).toLocaleString()} 个文本文件${res.truncated ? ' · 已达时间上限' : ''}`;
  } else {
    updateCount();
  }
  state.sel = state.results.length ? 0 : -1;
  paintSelection();
  if (state.results.length) select(0);
}

function appendRows(hits, base) {
  const q = state.query;
  $('#list').insertAdjacentHTML('beforeend',
    hits.map((h, i) => rowHtml(h, base + i, q)).join(''));
}

function rowHtml(h, i, q) {
  const name = h.name || h.path.split('\\').pop();
  const badge = h.count > 1 ? `<span class="cnt">${h.count} 处</span>` : '';
  const sub = state.mode === 'content'
    ? `<div class="snippet"><span class="ln">L${h.line}</span>${hl(h.text || '', q)}${badge}</div>`
    // 路径不再参与匹配，所以这里不做高亮——避免让人误以为是靠路径命中的
    : `<div class="pt">${esc(h.dir || '')}</div>`;
  return `<div class="row" data-i="${i}" style="animation-delay:${Math.min(i, 14) * 9}ms">
    <div class="ico">${icon(h.bucket, h.ext)}</div>
    <div class="mid">
      <div class="nm">${hl(name, q)}</div>
      ${sub}
    </div>
    <div class="tail"><div class="sz">${esc(h.size_text || '')}</div><div class="tm">${esc(h.time_text || '')}</div></div>
  </div>`;
}

/* ------------------------------------------------------------------ 内容搜索 */
async function runContent(q, my) {
  if (state.contentJob) { await api().job_cancel(state.contentJob); state.contentJob = null; }
  const scope = currentScope();
  $('#res-time').textContent = '检索中…';
  $('#st-mode').textContent = '内容模式 · 按需分层扫描';
  const { job } = await api().content_start(q, scope.drives, scope.buckets,
    state.sort, state.sortAsc);
  state.contentJob = job;
  pollContent(job, my);
}

async function pollContent(job, my) {
  const tick = async () => {
    if (my !== state.token) return;
    const p = await api().job_poll(job);
    if (p.state === 'running') {
      const pr = p.progress || {};
      $('#res-label').textContent = `检索中 · 已扫描 ${(pr.scanned || 0).toLocaleString()} 个文件`;
      $('#res-time').textContent = p.elapsed ? p.elapsed + 's' : '';
      setTimeout(tick, 220);
      return;
    }
    if (my !== state.token) return;
    state.contentJob = null;
    if (p.state === 'error') { toast('检索失败：' + p.error); return; }
    const res = p.result || { hits: [], scanned: 0, took_ms: 0 };
    state.results = res.hits;
    renderResults(res);
    $('#res-time').textContent = `${res.took_ms} ms`;
  };
  tick();
}

/* ------------------------------------------------------------------ 选择与预览 */
function paintSelection() {
  document.querySelectorAll('.row.sel').forEach((el) => el.classList.remove('sel'));
  const el = document.querySelector(`.row[data-i="${state.sel}"]`);
  if (el) {
    el.classList.add('sel');
    el.scrollIntoView({ block: 'nearest' });
  }
}

async function select(i) {
  if (i < 0 || i >= state.results.length) return;
  state.sel = i;
  paintSelection();
  const h = state.results[i];
  state.previewFor = h.path;
  // 快速连按上下键时不要把每个中间项都解析一遍：停 70ms 只算最后一次
  if (state.pvTimer) clearTimeout(state.pvTimer);
  if (SLOW_PREVIEW.has((h.ext || '').toLowerCase()) || h.bucket === 'dir') {
    paintPreviewSkeleton(h);
  }
  state.pvTimer = setTimeout(async () => {
    const data = await api().preview(h.path, state.query);
    if (state.previewFor !== h.path) return;
    renderPreview(data, h);
  }, 70);
}

// 这些类型要读文件、渲染图片，慢一些，先给个"正在生成"的占位
const SLOW_PREVIEW = new Set(['pdf', 'docx', 'docm', 'doc', 'dxf', 'dwg']);

function paintPreviewSkeleton(hit) {
  const meta = hit || {};
  $('#pv-empty').style.display = 'none';
  $('#pv-content').style.display = 'flex';
  $('#pv-ico').innerHTML = icon(meta.bucket || 'other', meta.ext);
  $('#pv-name').textContent = meta.name || (meta.path || '').split('\\').pop() || '—';
  $('#pv-sub').textContent = meta.dir || '';
  $('#pv-meta').innerHTML = '';
  $('#pv-body').innerHTML = '<div class="placeholder"><div class="spin"></div>正在生成预览…</div>';
}

function showPreviewEmpty() {
  $('#pv-empty').style.display = 'flex';
  const c = $('#pv-content');
  c.style.display = 'none';
}

function renderPreview(d, hit) {
  $('#pv-empty').style.display = 'none';
  const c = $('#pv-content');
  c.style.display = 'flex';
  const meta = d.meta || {};
  const name = meta.name || (hit && hit.path.split('\\').pop()) || '—';
  $('#pv-ico').innerHTML = icon(meta.bucket || (hit && hit.bucket) || 'other',
    meta.ext || (hit && hit.ext));
  $('#pv-name').textContent = name;
  $('#pv-sub').textContent = meta.dir || '';
  $('#pv-sub').title = meta.path || '';

  const rowset = [
    ['类型', (meta.ext || '').toUpperCase() || (meta.bucket === 'dir' ? '文件夹' : '—')],
    ['大小', meta.size_text || '—'],
    ['修改时间', meta.ctime_text || '—'],
    ['位置', meta.dir || '—'],
    ['只读', meta.readonly ? '是' : '否'],
  ];
  if (hit && hit.opens !== undefined && hit.bucket !== 'dir') {
    rowset.splice(3, 0, ['打开次数', `${hit.opens || 0} 次`]);
  }
  if (hit && hit.score !== undefined) rowset.push(['排序分', String(hit.score)]);
  $('#pv-meta').innerHTML = rowset.map(([k, v]) =>
    `<dt>${esc(k)}</dt><dd title="${esc(v)}">${esc(v)}</dd>`).join('');

  const body = $('#pv-body');
  const q = state.query;
  if (d.kind === 'image' && d.data) {
    body.innerHTML = `<div class="imgwrap"><img src="${d.data}" alt=""></div>`;
  } else if (d.kind === 'text' || d.kind === 'office') {
    const lines = d.lines || [];
    const toks = tokens(q);
    const html = lines.map((l) => {
      const low = String(l.t).toLowerCase();
      const isHit = toks.length > 0 && toks.every((t) => low.includes(t));
      return `<div class="ln${isHit ? ' hit' : ''}"><span class="no">${l.n}</span>
        <span class="tx">${hl(l.t === '' ? ' ' : l.t, q)}</span></div>`;
    }).join('');
    const tail = [];
    if (d.message) tail.push(d.message);
    if (d.legacy) tail.push('旧版 .doc 格式，只提取到文字（原排版无法还原）');
    if (d.truncated) tail.push(`已截断，仅显示前 ${lines.length} 行（共 ${d.total_lines || '?'} 行）`);
    const more = tail.length ? `<div class="more">… ${esc(tail.join(' · '))}</div>` : '';
    body.innerHTML = `<div class="code">${html}${more}</div>`;
    if (d.hit_line >= 0) {
      const el = body.querySelector('.ln.hit');
      if (el) el.scrollIntoView({ block: 'center' });
    }
  } else if (d.kind === 'dir') {
    body.innerHTML = dirHtml(d);
  } else if (d.kind === 'pdf' && d.img) {
    const pages = d.pages || 1;
    body.innerHTML = `<div class="docwrap"><img class="pageimg" src="${d.img}" alt=""></div>
      <div class="pv-note">第 1 页 · 共 ${pages} 页${d.paper ? ` · ${esc(d.paper)}` : ''}</div>`;
  } else if (d.kind === 'cad' && d.img) {
    const note = d.thumb
      ? `DWG 内置缩略图${d.ver ? `（${esc(d.ver)}）` : ''}`
      : `DXF 矢量预览 · ${d.entities || 0} 条线${d.texts ? ` / ${d.texts} 处文字` : ''}`;
    body.innerHTML = `<div class="docwrap"><img class="cadimg" src="${d.img}" alt=""></div>
      <div class="pv-note">${note}${d.truncated ? ' · 仅显示一部分' : ''}</div>`;
  } else if (d.kind === 'docx') {
    body.innerHTML = `<div class="dxstage"><div class="dxpaper">${d.html}</div></div>
      <div class="pv-note">${esc(docxNote(d))}</div>`;
    fitDocPaper(body);
    // 内嵌图片解码完成后高度会变，重新按比例缩放
    body.querySelectorAll('.dxpaper img').forEach((im) => {
      im.addEventListener('load', () => fitDocPaper(body));
      im.addEventListener('error', () => fitDocPaper(body));
    });
  } else if (d.kind === 'error') {
    body.innerHTML = `<div class="placeholder"><div class="big">${icon('other')}</div>${esc(d.message || '无法预览')}</div>`;
  } else {
    const label = d.message || { image: '图片过大，未生成缩略图',
      pdf: 'PDF 文档 · 双击用系统阅读器打开',
      video: '视频文件 · 双击用系统播放器打开', audio: '音频文件 · 双击用系统播放器打开',
      binary: '二进制文件，无文本预览' }[d.kind] || '暂无预览';
    body.innerHTML = `<div class="placeholder"><div class="big">${icon(meta.bucket || 'other', meta.ext)}</div>
      <div>${esc(label)}<br><span style="color:var(--text-3)">按 ↵ 打开，Ctrl+↵ 定位所在文件夹</span></div></div>`;
  }
}

/* ---------------------------------------------------------- 文件夹清单 */
function dirHtml(d) {
  if (d.message) {
    return `<div class="placeholder"><div class="big">${icon('dir')}</div>${esc(d.message)}</div>`;
  }
  const items = d.entries || [];
  if (!items.length) {
    return `<div class="placeholder"><div class="big">${icon('dir')}</div>空文件夹</div>`;
  }
  const rows = items.map((e) => `<div class="drow" data-open="${esc(e.path)}" title="${esc(e.path)}">
      <span class="dico">${icon(e.bucket, e.ext)}</span>
      <span class="dname">${esc(e.name)}</span>
      <span class="dsize">${esc(e.size_text || '')}</span>
    </div>`).join('');
  let right = '';
  if (d.truncated) {
    right = `仅显示前 ${items.length} 项${
      d.scanned >= 5000 ? '（目录很大）' : `（共 ${d.total} 项）`}`;
  }
  return `<div class="dhead"><span>${d.dirs || 0} 个文件夹 · ${d.files || 0} 个文件</span>
    <span>${esc(right)}</span></div><div class="dlist">${rows}</div>`;
}

/* ------------------------------------------------------------ Word 版面 */
function docxNote(d) {
  const bits = [];
  const p = d.paper || {};
  if (p.w_cm) bits.push(`${p.w_cm}×${p.h_cm} cm`);
  if (d.chars) bits.push(`${d.chars.toLocaleString()} 字`);
  if (d.tables) bits.push(`${d.tables} 个表格`);
  if (d.images) bits.push(`${d.images} 张图`);
  if (d.truncated) bits.push('内容过长，仅显示前面部分');
  return bits.join(' · ') || 'Word 文档';
}

// 把「按真实纸张宽度排好版」的文档整体缩放到预览窗格里：
// 不做文本重排，缩进和字号比例才跟原文档一致。
function fitDocPaper(root) {
  const stage = root.querySelector('.dxstage');
  const paper = root.querySelector('.dxpaper');
  if (!stage || !paper) return;
  const avail = Math.max(120, (root.clientWidth || 360) - 26);
  const pw = paper.offsetWidth || Math.round(paper.scrollWidth) || 794;
  const k = Math.min(1, avail / pw);
  paper.style.transform = `scale(${k})`;
  stage.style.width = Math.round(pw * k) + 'px';
  stage.style.height = Math.round(paper.offsetHeight * k) + 'px';
}

/* ------------------------------------------------------------------ 交互 */
function bindEvents() {
  const q = $('#q');
  q.addEventListener('input', scheduleSearch);

  q.addEventListener('keydown', async (e) => {
    if (e.key === 'ArrowDown' || (e.key === 'n' && e.ctrlKey)) {
      e.preventDefault();
      if (state.results.length) select(Math.min(state.results.length - 1, state.sel + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      select(Math.max(0, state.sel - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const hit = state.results[state.sel];
      if (!hit) return;
      const r = e.ctrlKey ? await api().reveal_path(hit.path) : await api().open_path(hit.path);
      if (!r.ok) toast(r.message || '打不开这个文件');
      else if (!e.ctrlKey) toast('已打开：' + hit.path.split('\\').pop());
    } else if (e.key === 'Escape') {
      q.value = '';
      state.query = '';
      clearResults();
    }
  });

  $('#list').addEventListener('click', (e) => {
    const row = e.target.closest('.row');
    if (row) select(+row.dataset.i);
  });
  $('#list').addEventListener('dblclick', async (e) => {
    const row = e.target.closest('.row');
    if (!row) return;
    const hit = state.results[+row.dataset.i];
    const r = await api().open_path(hit.path);
    if (!r.ok) toast(r.message);
  });

  document.querySelectorAll('.seg button').forEach((b) => {
    b.addEventListener('click', () => setMode(b.dataset.mode));
  });

  // 手动视图模式：排序按钮 + 下拉
  $('#sort-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    const open = $('#sort-menu').classList.toggle('show');
    $('#sort-btn').classList.toggle('open', open);
  });
  $('#sort-menu').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-sort]');
    if (!b) return;
    e.stopPropagation();
    setSort(b.dataset.sort);
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#sortwrap')) closeSortMenu();
  });

  $('#drives').addEventListener('click', (e) => {
    const el = e.target.closest('.tier');
    if (!el) return;
    if (el.dataset.idle) {                 // 「＋ N 个未建索引的盘符」→ 展开/收起
      state.showIdle = !state.showIdle;
      renderDrives();
      return;
    }
    const d = el.dataset.drive;
    state.drives.has(d) ? state.drives.delete(d) : state.drives.add(d);
    if (!state.drives.size) state.drives.add(d);
    el.classList.toggle('on');
    el.classList.toggle('off');
    persistScope();
    if (state.query) scheduleSearch();
  });

  $('#buckets').addEventListener('click', (e) => {
    const el = e.target.closest('.tier');
    if (!el) return;
    const b = el.dataset.bucket;
    state.buckets.has(b) ? state.buckets.delete(b) : state.buckets.add(b);
    el.classList.toggle('on');
    el.classList.toggle('off');
    persistScope();
    if (state.query) scheduleSearch();
  });

  // 窗口与标题栏
  $('#btn-close').addEventListener('click', () => api().win_close());
  $('#btn-min').addEventListener('click', () => api().win_minimize());
  $('#btn-max').addEventListener('click', async () => {
    await api().win_toggle_max();
    refreshWinState();
  });

  /* 拖动交给系统的非客户区拖动：跟手、支持贴边吸附（顶部最大化 / 左右半屏）。
     双击标题栏自己判定，因为无边框窗口没有 WS_CAPTION，系统的非客户区双击不可用。 */
  const tb = $('#titlebar');
  let lastDown = 0;
  let downX = 0;
  let downY = 0;
  tb.addEventListener('mousedown', (e) => {
    if (e.button !== 0 || e.target.closest('button')) return;
    e.preventDefault();
    const now = Date.now();
    if (now - lastDown < 320 && Math.abs(e.clientX - downX) < 6 && Math.abs(e.clientY - downY) < 6) {
      lastDown = 0;
      api().win_toggle_max().then(refreshWinState);
      return;
    }
    lastDown = now;
    downX = e.clientX;
    downY = e.clientY;
    api().win_drag();
  });

  // 拖动结束后同步最大化状态（贴边吸附是系统做的，界面要知道结果）
  document.addEventListener('mouseup', () => {
    if (!state.ready) return;
    setTimeout(refreshWinState, 140);
  });

  // 结果列表滚动到底：按需加载下一页
  $('#list').addEventListener('scroll', () => {
    const el = $('#list');
    if (el.scrollTop + el.clientHeight >= el.scrollHeight - 240) loadMore();
  });

  $('#btn-preview').addEventListener('click', () => {
    $('#app').classList.toggle('no-preview');
    fitLayout();
  });

  // 预览动作
  $('#pv-open').addEventListener('click', async () => {
    const p = state.previewFor;
    if (!p) return;
    const r = await api().open_path(p);
    if (!r.ok) toast(r.message);
  });
  $('#pv-reveal').addEventListener('click', async () => {
    const p = state.previewFor;
    if (p) await api().reveal_path(p);
  });
  $('#pv-copy').addEventListener('click', async () => {
    const ok = await copyText(state.previewFor || '');
    toast(ok ? '路径已复制' : '复制失败');
  });

  // 索引
  $('#btn-build').addEventListener('click', startIndex);
  $('#btn-build').addEventListener('contextmenu', (e) => { e.preventDefault(); startIndex(true); });
  $('#btn-clear').addEventListener('click', async () => {
    for (const d of state.drives) await api().index_clear(d);
    const b = await api().boot();
    state.boot.tiers = b.tiers;
    state.boot.drives = b.drives;
    renderDrives(); renderBuckets(); renderIndexState();
    toast('已清空所选盘的索引');
  });

  // 设置
  $('#btn-settings').addEventListener('click', openSettings);
  document.querySelectorAll('#theme-seg button').forEach((b) => {
    b.addEventListener('click', () => setTheme(b.dataset.theme));
  });
  $('#set-cancel').addEventListener('click', () => $('#overlay').classList.remove('show'));
  $('#set-save').addEventListener('click', saveSettings);
  $('#ws-add').addEventListener('click', addWorkspace);
  document.querySelectorAll('.wrange').forEach((r) => r.addEventListener('input', syncWeightLabels));
  window.addEventListener('resize', () => {
    fitLayout();
    debounce2();
    const body = $('#pv-body');
    if (body.querySelector('.dxpaper')) fitDocPaper(body);
  });

  // 文件夹清单里点一条就打开它
  $('#pv-body').addEventListener('click', async (e) => {
    const row = e.target.closest('.drow');
    if (!row) return;
    const p = row.dataset.open;
    if (!p) return;
    const r = await api().open_path(p);
    if (r && !r.ok) toast(r.message || '打不开这个文件');
  });

  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      $('#q').focus();
      $('#q').select();
    } else if (e.key === 'Escape') {
      $('#overlay').classList.remove('show');
      $('#confirm').classList.remove('show');
      closeSortMenu();
    }
  });
}

let resizeTimer = null;
function debounce2() {
  clearTimeout(resizeTimer);
  if (state.maxed) return;                     // 最大化时的尺寸不作为下次启动的尺寸
  resizeTimer = setTimeout(() => api().save_window(window.outerWidth, window.outerHeight), 700);
}

function fitLayout() {
  const w = window.innerWidth;
  $('#app').classList.toggle('compact', w < 1120);
}

/* 最大化时把界面按「窗口超出工作区的像素数」内缩，避免无边框窗口的内容被屏幕边缘裁掉。 */
function syncMaxClass(on, inset) {
  const app = $('#app');
  state.maxed = !!on;
  app.classList.toggle('maximized', !!on);
  if (on && inset) {
    app.style.margin = `${inset.t}px ${inset.r}px ${inset.b}px ${inset.l}px`;
    app.style.height = `calc(100vh - ${inset.t + inset.b}px)`;
    app.style.width = `calc(100vw - ${inset.l + inset.r}px)`;
  } else {
    app.style.margin = '';
    app.style.height = '';
    app.style.width = '';
  }
}

async function refreshWinState() {
  try {
    const s = await api().win_state();
    syncMaxClass(!!s.maximized, s.inset);
  } catch (e) { /* 窗口正在销毁时忽略 */ }
}

/* 系统可能通过 Win+方向键、贴边吸附等改变最大化状态，定时对齐一次界面状态。 */
function startWinWatch() {
  setInterval(() => {
    if (!state.ready || document.hidden) return;
    refreshWinState();
  }, 1200);
}

function positionPill() {
  const btn = document.querySelector(`.seg button[data-mode="${state.mode}"]`);
  if (!btn) return;
  const pill = $('#pill');
  pill.style.width = btn.offsetWidth + 'px';
  pill.style.transform = `translateX(${btn.offsetLeft - 2}px)`;
}

/* ------------------------------------------------------ 手动视图模式（排序）
   默认「相关度」= 原来的智能排序；其余五种是用户可控的固定列排序。
   后端按所选列重排后再分页，所以滚动加载出来的顺序也是一致的。 */
function syncSortUI() {
  const mode = SORT_LABEL[state.sort] ? state.sort : 'relevance';
  state.sort = mode;
  $('#sort-label').textContent = SORT_LABEL[mode];
  const btn = $('#sort-btn');
  btn.classList.toggle('nodir', mode === 'relevance');
  btn.classList.toggle('asc', mode !== 'relevance' && !!state.sortAsc);
  document.querySelectorAll('#sort-menu button').forEach((b) => {
    const on = b.dataset.sort === mode;
    b.classList.toggle('on', on);
    const ar = b.querySelector('.ar');
    if (ar) ar.textContent = (on && mode !== 'relevance') ? (state.sortAsc ? '↑' : '↓') : '';
  });
  $('#sort-note').textContent = SORT_NOTE[mode] || SORT_NOTE.relevance;
}

function closeSortMenu() {
  $('#sort-menu').classList.remove('show');
  $('#sort-btn').classList.remove('open');
}

async function setSort(mode) {
  if (!SORT_LABEL[mode]) return;
  closeSortMenu();
  if (mode === state.sort) {
    if (mode === 'relevance') return;          // 相关度只有一种方向
    state.sortAsc = !state.sortAsc;            // 再点当前项 → 反向
  } else {
    state.sort = mode;
    state.sortAsc = SORT_DEFAULT_ASC[mode];
  }
  syncSortUI();
  state.settings.sort = state.sort;
  state.settings.sort_asc = state.sortAsc;
  await api().set_settings({ sort: state.sort, sort_asc: state.sortAsc });
  if (state.query && tokens(state.query).length) scheduleSearch();
  else updateCount();
}

function setMode(mode) {
  if (state.mode === mode) return;
  state.mode = mode;
  document.querySelectorAll('.seg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === mode));
  positionPill();
  $('#q').placeholder = mode === 'content'
    ? '在文件内容中搜索…（空格分隔多个关键词）'
    : '搜索文件…（空格分隔多个关键词）';
  $('#st-mode').textContent = mode === 'content' ? '内容模式 · 按需分层扫描' : '文件名模式 · 即时';
  if (state.query) scheduleSearch();
  else clearResults();
}

async function persistScope() {
  await api().set_settings({ drives: [...state.drives], buckets: [...state.buckets] });
}

/* ------------------------------------------------------------------ 索引任务 */
async function startIndex(silentAsk) {
  const drives = [...state.drives];
  if (!drives.length) { toast('先在左侧选择至少一个盘符'); return; }
  await persistScope();
  if (!silentAsk) {
    const ok = await ask('建立分级索引', `将对 ${drives.join('、')} 遍历并建立按类型分层的索引。\n\n· 只记录路径、大小、修改时间，不读取文件内容\n· 首次全盘遍历通常需要 1–5 分钟\n· 过程中可随时取消，界面不会卡住`);
    if (!ok) return;
  }
  const { job } = await api().index_start(null);
  $('#btn-build').disabled = true;
  $('#btn-build').textContent = '正在建立索引…';
  $('#ibar').style.display = 'block';
  pollIndex(job);
}

function ask(title, msg) {
  return new Promise((resolve) => {
    const box = $('#confirm');
    $('#cf-title').textContent = title;
    $('#cf-msg').textContent = msg;
    box.classList.add('show');
    const okBtn = $('#cf-ok');
    const cancelBtn = $('#cf-cancel');
    const finish = (v) => {
      box.classList.remove('show');
      okBtn.removeEventListener('click', onOk);
      cancelBtn.removeEventListener('click', onCancel);
      resolve(v);
    };
    const onOk = () => finish(true);
    const onCancel = () => finish(false);
    okBtn.addEventListener('click', onOk);
    cancelBtn.addEventListener('click', onCancel);
  });
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) { /* 回退到 execCommand */ }
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;left:-9999px;opacity:0';
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
  ta.remove();
  return ok;
}

async function pollIndex(job) {
  const p = await api().job_poll(job);
  if (p.state === 'running') {
    const pr = p.progress || {};
    if (pr.drive) {
      $('#st-index').textContent = `建立 ${pr.drive} 索引 · 已扫描 ${(pr.count || 0).toLocaleString()} 个条目`;
      $('#idx-state').textContent = `${(pr.count || 0).toLocaleString()}`;
      if (pr.current) $('#btn-build').title = pr.current;
    }
    setTimeout(() => pollIndex(job), 350);
    return;
  }
  $('#btn-build').disabled = false;
  $('#btn-build').textContent = '建立 / 更新索引';
  $('#ibar').style.display = 'none';
  if (p.state === 'error') { toast('索引失败：' + p.error); return; }
  const boot = await api().boot();
  state.boot.tiers = boot.tiers;
  state.boot.drives = boot.drives;
  renderDrives();
  renderBuckets();
  renderIndexState();
  const built = (p.result && p.result.built) || [];
  const total = built.reduce((a, b) => a + (b.count || 0), 0);
  const secs = built.reduce((a, b) => a + (b.seconds || 0), 0);
  toast(`索引完成 · ${total.toLocaleString()} 项 / ${secs.toFixed(1)} 秒`);
  if (state.query) scheduleSearch();
}

/* ------------------------------------------------------------------ 设置面板 */
function openSettings() {
  const s = state.settings;
  const w = s.weights || {};
  $('#w-frec').value = w.frecency ?? 1;
  $('#w-ws').value = w.workspace ?? 1;
  $('#w-rec').value = w.recency ?? 1;
  $('#w-sys').value = w.system ?? 1;
  $('#c-max').value = s.content_max_mb ?? 2;
  syncThemeSeg();
  renderWsList();
  syncWeightLabels();
  $('#overlay').classList.add('show');
}

/* ------------------------------------------------------------------ 主题 */
const THEME_LABEL = { dark: '深色', light: '浅色', auto: '跟随系统' };

function currentTheme() {
  return (state.settings && state.settings.theme) || 'dark';
}

function applyTheme(pref) {
  const p = pref || currentTheme();
  const dark = p === 'dark'
    || (p === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  $('#theme-cur').textContent = THEME_LABEL[p] || '深色';
  document.querySelectorAll('#theme-seg button').forEach((b) => {
    b.classList.toggle('on', b.dataset.theme === p);
  });
  // 窗口四周那圈非客户区（拖拽缩放热区）由系统上色，浅色时要去掉黑边
  const a = window.pywebview && window.pywebview.api;
  if (a && a.win_theme) a.win_theme(dark ? 'dark' : 'light');
}

function syncThemeSeg() {
  applyTheme(currentTheme());
}

function setTheme(pref) {
  state.settings.theme = pref;
  applyTheme(pref);
}

// 选「跟随系统」时，系统在深浅之间切换要实时生效
if (window.matchMedia) {
  window.matchMedia('(prefers-color-scheme: dark)')
    .addEventListener('change', () => { if (currentTheme() === 'auto') applyTheme('auto'); });
}

function syncWeightLabels() {
  $('#w-frec-v').textContent = Number($('#w-frec').value).toFixed(1);
  $('#w-ws-v').textContent = Number($('#w-ws').value).toFixed(1);
  $('#w-rec-v').textContent = Number($('#w-rec').value).toFixed(1);
  $('#w-sys-v').textContent = Number($('#w-sys').value).toFixed(1);
  $('#c-max-v').textContent = Number($('#c-max').value).toFixed(1) + ' MB';
}

function renderWsList() {
  const list = state.settings.workspaces || [];
  $('#wslist').innerHTML = list.map((p, i) => `
    <div class="wsrow"><span title="${esc(p)}">${esc(p)}</span>
      <button data-i="${i}" title="移除">×</button></div>`).join('')
    || '<div class="wsrow" style="color:var(--text-3)">尚未设置工作区</div>';
  $('#wslist').querySelectorAll('button').forEach((b) => b.addEventListener('click', () => {
    state.settings.workspaces.splice(+b.dataset.i, 1);
    renderWsList();
  }));
}

function addWorkspace() {
  const v = $('#ws-input').value.trim();
  if (!v) return;
  state.settings.workspaces = state.settings.workspaces || [];
  if (!state.settings.workspaces.includes(v)) state.settings.workspaces.push(v);
  $('#ws-input').value = '';
  renderWsList();
}

async function saveSettings() {
  const patch = {
    workspaces: state.settings.workspaces || [],
    content_max_mb: Number($('#c-max').value),
    theme: state.settings.theme || 'dark',
    weights: {
      frecency: Number($('#w-frec').value),
      workspace: Number($('#w-ws').value),
      recency: Number($('#w-rec').value),
      system: Number($('#w-sys').value),
    },
  };
  const r = await api().set_settings(patch);
  state.settings = r.settings;
  $('#overlay').classList.remove('show');
  toast('设置已保存');
  if (state.query) scheduleSearch();
}

function updateStatus() {
  const total = Object.values(state.boot.tiers.drives || {}).reduce((a, d) => a + (d.count || 0), 0);
  $('#st-index').textContent = total
    ? `索引 ${total.toLocaleString()} 项 · ${state.drives.size} 个盘 · 只读索引，无网络`
    : '索引为空 · 点左下角「建立索引」开始';
  if (!total && !state.query) {
    $('#empty').querySelector('h3').textContent = '首次使用 · 先建立索引';
    $('#empty').querySelector('p').innerHTML =
      '点左下角「建立 / 更新索引」，按盘符与文件类型分层扫描<br>' +
      '只记录路径、大小、修改时间，不读取文件内容';
  }
}

/* pywebview 注入时机存在竞态：事件可能早于脚本注册就已触发，
   因此事件 + 轮询双保险，保证 init 只执行一次。 */
function bootWhenReady() {
  if (state.ready || state.starting) return;
  const apiObj = window.pywebview && window.pywebview.api;
  if (apiObj && typeof apiObj.boot === 'function') {
    state.starting = true;
    init().catch((e) => {
      document.body.innerHTML =
        `<pre style="color:#f88;padding:20px;font-size:12px;white-space:pre-wrap">${esc(String((e && e.stack) || e))}</pre>`;
    });
    return;
  }
  state.tries = (state.tries || 0) + 1;
  if (state.tries > 120) {
    const dbg = `tries=${state.tries} py=${!!window.pywebview} api=${window.pywebview ? typeof window.pywebview.api : 'none'} ` +
      `keys=${window.pywebview && window.pywebview.api ? Object.keys(window.pywebview.api).length : 0}`;
    document.body.insertAdjacentHTML('beforeend',
      `<div style="position:fixed;inset:0;display:grid;place-items:center;color:#888;font-size:13px">
         请通过 OK搜索.exe 启动（浏览器环境无法访问本地索引）<br><span style="font-size:11px;opacity:.6">${esc(dbg)}</span></div>`);
    return;
  }
  setTimeout(bootWhenReady, 50);
}

window.addEventListener('pywebviewready', bootWhenReady);
document.addEventListener('DOMContentLoaded', () => setTimeout(bootWhenReady, 30));
setTimeout(bootWhenReady, 60);
